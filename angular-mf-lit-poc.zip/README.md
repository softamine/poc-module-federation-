# Angular Module Federation POC

Contient deux composants exposés via MF.