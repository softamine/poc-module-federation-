import { loadRemoteModule } from '@angular-architects/module-federation';
import { Component, ViewChild, ViewContainerRef, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-diagnostic',
  standalone: true,
  template: \`
    <h1>Page de diagnostic</h1>
    <ng-container #vc1></ng-container>
    <hr />
    <ng-container #vc2></ng-container>
  \`
})
export class DiagnosticComponent implements AfterViewInit {
  @ViewChild('vc1', { read: ViewContainerRef }) vc1!: ViewContainerRef;
  @ViewChild('vc2', { read: ViewContainerRef }) vc2!: ViewContainerRef;

  async ngAfterViewInit() {
    const { AlerteJustifiableComponent } = await loadRemoteModule({
      remoteEntry: 'http://localhost:4201/remoteEntry.js',
      remoteName: 'console',
      exposedModule: './AlerteJustifiable'
    });

    const { DonneesDocumentairesComponent } = await loadRemoteModule({
      remoteEntry: 'http://localhost:4201/remoteEntry.js',
      remoteName: 'console',
      exposedModule: './DonneesDocumentaires'
    });

    const compRef1 = this.vc1.createComponent(AlerteJustifiableComponent);
    compRef1.setInput('identifiant', 'H123452234');
    compRef1.setInput('date', '28/05/2025');
    compRef1.instance.alerteValidee.subscribe(e => console.log('Validé : ', e));
    compRef1.instance.alerteRejetee.subscribe(e => console.log('Rejeté : ', e));

    this.vc2.createComponent(DonneesDocumentairesComponent);
  }
}