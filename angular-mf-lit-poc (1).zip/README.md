# Angular MF POC

Deux composants Angular exposés et chargés dynamiquement via Federation.