import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-donnees-documentaires',
  standalone: true,
  template: \`
    <h3>Données documentaires</h3>
    <label>Numéro CNI :</label>
    <input [value]="cni" (input)="onInputChange($event)" />
    <button (click)="onValidate()">Valider</button>
  \`
})
export class DonneesDocumentairesComponent {
  @Input() cni: string = '123 456 4567 2134';

  onInputChange(event: Event) {
    const target = event.target as HTMLInputElement;
    this.cni = target.value;
  }

  onValidate() {
    const channel = new BroadcastChannel('data-validation');
    channel.postMessage({ cni: this.cni });
  }
}