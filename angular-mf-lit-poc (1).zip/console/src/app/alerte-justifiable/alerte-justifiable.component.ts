import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-alerte-justifiable',
  standalone: true,
  template: \`
    <div>
      <h3>Alertes Justifiables</h3>
      <p>{{identifiant}} OK fait le {{date}}</p>
      <p>{{statut}}</p>
      <button (click)="validate()">Valider</button>
      <button (click)="reject()">Rejeter</button>
    </div>
  \`
})
export class AlerteJustifiableComponent {
  @Input() identifiant = '';
  @Input() date = '';
  statut = '';
  validated = false;

  @Output() alerteValidee = new EventEmitter<any>();
  @Output() alerteRejetee = new EventEmitter<any>();

  validate() {
    this.validated = true;
    this.statut = 'validé';
    this.alerteValidee.emit({ opportunityId: this.identifiant });
  }

  reject() {
    this.validated = false;
    this.statut = 'rejeté';
    this.alerteRejetee.emit({ opportunityId: this.identifiant });
  }
}